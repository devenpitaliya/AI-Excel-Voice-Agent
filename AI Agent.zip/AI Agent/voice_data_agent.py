import streamlit as st
import pandas as pd
import speech_recognition as sr
#from langchain_community.llms import OpenAI
from langchain_openai import OpenAI
from gtts import gTTS
import os
import tempfile
import openpyxl
from langchain_experimental.agents import create_pandas_dataframe_agent
import tabulate

# Setup OpenAI API key
os.environ["OPENAI_API_KEY"] = st.secrets["OPENAI_API_KEY"]

st.set_page_config(page_title="🎤 AI Excel Voice Agent", layout="centered")
st.title("🎤 Ask Your Excel File — With Your Voice!")

# ✅ Excel file path (adjust this if needed)
# ✅ Excel file path
# ✅ Excel file path
FILE_PATH = r"C:\Users\Devendra Pitaliya\Desktop\Agent AI\pythonProject\ExceptionInvoices.xlsx"
#C:\Users\Devendra Pitaliya\Desktop\Agent AI\pythonProject\ExceptionInvoices.xlsx
try:
    df = pd.read_excel(FILE_PATH)
    st.success(f"Loaded file: {FILE_PATH}")
    st.dataframe(df.head())

    llm = OpenAI(temperature=0, model="gpt-4")
    agent = create_pandas_dataframe_agent(
        llm,
        df,
        verbose=False,
        agent_type="openai-functions",
        allow_dangerous_code=True
    )

except Exception as e:
    st.error(f"Error loading Excel file: {e}")
    st.stop()


# ✅ Create LangChain Pandas agent
#llm = OpenAI(temperature=0, model="gpt-4")
#agent = create_pandas_dataframe_agent(llm, df, verbose=False)

# ✅ Session chat history
if "history" not in st.session_state:
    st.session_state.history = []
# ✅ Voice input section
st.subheader("🎙️ Ask a Question via Voice")
if st.button("Start Recording"):
    r = sr.Recognizer()
    with sr.Microphone() as source:
        st.info("🎤 Listening... Speak now.")
        try:
            audio = r.listen(source, timeout=5)
            query = r.recognize_google(audio)
            st.success(f"🧑 You said: **{query}**")

            with st.spinner("🤖 Thinking..."):
                response = agent.run(query)
                st.session_state.history.append(("You", query))
                st.session_state.history.append(("Agent", response))

                # ✅ Convert to speech
                tts = gTTS(text=response, lang='en')
                with tempfile.NamedTemporaryFile(delete=False, suffix=".mp3") as fp:
                    tts.save(fp.name)
                    st.audio(fp.name, format="audio/mp3")

        except sr.UnknownValueError:
            st.error("❌ Could not understand your voice.")
        except sr.WaitTimeoutError:
            st.error("⏱️ No voice detected. Try again.")
        except Exception as e:
            st.error(f"❌ Error: {e}")

# ✅ Show chat history
st.subheader("🕑 Conversation History")
for role, msg in reversed(st.session_state.history):
    st.markdown(f"**{role}:** {msg}")